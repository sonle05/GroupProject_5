DỮ LIỆU DÀNH RIÊNG CHO NHÓM 5
====================================
1. File SQL: init.sql (Chứa 20000 đơn hàng mẫu).
2. File CSV: inventory.csv (Chứa 5000 dòng tồn kho).

LƯU Ý QUAN TRỌNG:
- Dữ liệu CSV của nhóm bạn chứa các loại lỗi đặc thù (Dirty Data).
- Mã chiến lược lỗi của nhóm: OUTLIERS
- Các bạn phải viết code Python (Module 1) để tự động phát hiện và xử lý các lỗi này.
- KHÔNG ĐƯỢC sửa tay file CSV. Code phải có block try-except để bỏ qua hoặc sửa lỗi.
